const { app, BrowserWindow, ipcMain, shell, dialog, nativeTheme } = require('electron');
const path = require('path');
const fs   = require('fs');
const http = require('http');
const https = require('https');
const Store = require('electron-store');

// ── Persistent settings (API key, window size, etc.) ─────────────────────────
const store = new Store({
  encryptionKey: 'foxflowers-2024-secure'   // encrypts key on disk
});

// ── Uploads folder: stored in user's app data, persists across updates ────────
const uploadsDir = path.join(app.getPath('userData'), 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

let mainWindow;

function createWindow() {
  nativeTheme.themeSource = 'light';

  mainWindow = new BrowserWindow({
    width:  1100,
    height: 820,
    minWidth: 800,
    minHeight: 600,
    title: 'Fox Flowers — Invoice Scanner',
    backgroundColor: '#f5f2ee',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    },
    ...(process.platform === 'darwin' ? {
      titleBarStyle: 'hiddenInset',
      trafficLightPosition: { x: 16, y: 16 }
    } : {
      autoHideMenuBar: true
    })
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// ── IPC: settings ─────────────────────────────────────────────────────────────
ipcMain.handle('get-setting', (e, key)        => store.get(key));
ipcMain.handle('set-setting', (e, key, value) => { store.set(key, value); return true; });
ipcMain.handle('get-uploads-dir', ()          => uploadsDir);

// ── IPC: list saved images ────────────────────────────────────────────────────
ipcMain.handle('list-images', () => {
  const exts = new Set(['.jpg','.jpeg','.png','.gif','.webp','.heic','.heif']);
  try {
    return fs.readdirSync(uploadsDir)
      .filter(f => exts.has(path.extname(f).toLowerCase()))
      .map(f => {
        const full = path.join(uploadsDir, f);
        const stat = fs.statSync(full);
        return { filename: f, path: full, size: stat.size, mtime: stat.mtimeMs };
      })
      .sort((a, b) => b.mtime - a.mtime);
  } catch(e) { return []; }
});

// ── IPC: save uploaded image to disk ─────────────────────────────────────────
ipcMain.handle('save-image', (e, { name, base64, mimeType }) => {
  const ext  = path.extname(name) || '.jpg';
  const base = path.basename(name, ext).replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 80);
  const filename = `${Date.now()}_${base}${ext}`;
  const fullPath = path.join(uploadsDir, filename);
  fs.writeFileSync(fullPath, Buffer.from(base64, 'base64'));
  return { filename, path: fullPath };
});

// ── IPC: delete image ─────────────────────────────────────────────────────────
ipcMain.handle('delete-image', (e, filename) => {
  const safe = path.basename(filename);
  const full = path.join(uploadsDir, safe);
  if (fs.existsSync(full)) fs.unlinkSync(full);
  return true;
});

// ── IPC: read image as base64 (for AI scanning) ───────────────────────────────
ipcMain.handle('read-image-base64', (e, filename) => {
  const safe = path.basename(filename);
  const full = path.join(uploadsDir, safe);
  if (!fs.existsSync(full)) throw new Error('File not found: ' + safe);
  return fs.readFileSync(full).toString('base64');
});

// ── IPC: call Anthropic API (from main process — no CORS restrictions) ────────
ipcMain.handle('scan-invoice', async (e, { filename, model, apiKey }) => {
  const base64   = await ipcMain.handle !== undefined
    ? fs.readFileSync(path.join(uploadsDir, path.basename(filename))).toString('base64')
    : null;

  const ext = path.extname(filename).toLowerCase();
  const mimeMap = { '.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.gif':'image/gif','.webp':'image/webp' };
  const mediaType = mimeMap[ext] || 'image/jpeg';

  const imgBase64 = fs.readFileSync(path.join(uploadsDir, path.basename(filename))).toString('base64');

  const prompt = `You are helping a flower shop called Fox Flowers read their handwritten order forms and invoices.

Look at this handwritten invoice or order form and extract the data into a JSON array ready to import into QuickBooks Online.

Return ONLY a valid JSON array of objects. Use these EXACT JSON keys:
- "InvoiceNo": invoice or order number if visible, otherwise leave blank
- "Customer": the name of the person or company being billed
- "InvoiceDate": the order or invoice date in DD/MM/YYYY format
- "DueDate": delivery date if shown in DD/MM/YYYY format, otherwise leave blank
- "Terms": payment terms if shown (e.g. "Due on receipt"), otherwise "Due on receipt"
- "Memo": delivery time, special instructions, or any notes
- "ItemDescription": describe what was ordered, who it is for, and who ordered it if a company. Be descriptive but concise.
- "ItemQuantity": quantity if shown, otherwise 1
- "ItemRate": price per unit if shown, otherwise leave blank
- "ItemAmount": the REMAINING TO PAY amount if shown, otherwise the total amount

If there are multiple line items, return one object per line item. Repeat InvoiceNo and Customer on each row.
Return ONLY the raw JSON array. No markdown. No code fences. No explanation.`;

  const body = JSON.stringify({
    model: model || 'claude-sonnet-4-5-20250929',
    max_tokens: 1000,
    messages: [{ role: 'user', content: [
      { type: 'image', source: { type: 'base64', media_type: mediaType, data: imgBase64 } },
      { type: 'text', text: prompt }
    ]}]
  });

  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: 'api.anthropic.com',
      path: '/v1/messages',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (parsed.error) return reject(new Error(parsed.error.message || 'API error'));
          const textBlock = Array.isArray(parsed.content) && parsed.content.find(b => b.type === 'text');
          if (!textBlock) return reject(new Error('No text in response'));
          const aiText = textBlock.text.trim();
          const clean  = aiText.replace(/^```[\w]*\n?/m,'').replace(/```$/m,'').trim();
          const rows   = JSON.parse(clean);
          resolve(Array.isArray(rows) ? rows : [rows]);
        } catch(e) { reject(new Error('Could not parse response: ' + data.slice(0, 100))); }
      });
    });
    req.on('error', e => reject(new Error('Network error: ' + e.message)));
    req.write(body);
    req.end();
  });
});

// ── IPC: save CSV to disk via save dialog ─────────────────────────────────────
ipcMain.handle('save-csv', async (e, csvContent) => {
  const { filePath } = await dialog.showSaveDialog(mainWindow, {
    title: 'Save QuickBooks CSV',
    defaultPath: path.join(app.getPath('documents'), 'fox_flowers_quickbooks.csv'),
    filters: [{ name: 'CSV Files', extensions: ['csv'] }]
  });
  if (!filePath) return false;
  fs.writeFileSync(filePath, csvContent, 'utf8');
  shell.showItemInFolder(filePath);
  return true;
});
