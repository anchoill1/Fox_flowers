const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('foxAPI', {
  // Settings
  getSetting:       (key)              => ipcRenderer.invoke('get-setting', key),
  setSetting:       (key, value)       => ipcRenderer.invoke('set-setting', key, value),
  getUploadsDir:    ()                 => ipcRenderer.invoke('get-uploads-dir'),

  // Images
  listImages:       ()                 => ipcRenderer.invoke('list-images'),
  saveImage:        (data)             => ipcRenderer.invoke('save-image', data),
  deleteImage:      (filename)         => ipcRenderer.invoke('delete-image', filename),
  readImageBase64:  (filename)         => ipcRenderer.invoke('read-image-base64', filename),

  // AI
  scanInvoice:      (data)             => ipcRenderer.invoke('scan-invoice', data),

  // Export
  saveCSV:          (content)          => ipcRenderer.invoke('save-csv', content),
});
