# 🌸 Fox Flowers Invoice Scanner — Electron App

A standalone desktop app (Mac + Windows) that reads handwritten invoices using AI and exports a QuickBooks CSV.

---

## For end users
Just download and open the app. No setup needed.
- **Mac**: open the `.dmg`, drag to Applications
- **Windows**: run the `.exe` installer

On first launch the app asks for your Anthropic API key (get one at console.anthropic.com). It's saved securely on your device.

---

## For developers — building the app

### Prerequisites
- Node.js 18+ (https://nodejs.org)
- On Mac: Xcode command line tools (`xcode-select --install`)
- On Windows: Build tools (`npm install --global windows-build-tools`)

### Install dependencies
```
npm install
```

### Run in development
```
npm start
```

### Build for Mac (creates .dmg in /dist)
```
npm run build:mac
```

### Build for Windows (creates .exe installer in /dist)
```
npm run build:win
```

### Build for both
```
npm run build:all
```

> Note: Mac builds can only be code-signed on a Mac with an Apple Developer account.
> Windows builds can be built from either Mac or Windows.

---

## Project structure
```
foxflowers-electron/
├── src/
│   ├── main.js       ← Electron main process (file system, API calls)
│   ├── preload.js    ← Secure bridge between main and UI
│   └── index.html    ← The app UI
├── assets/
│   ├── icon.icns     ← Mac app icon (add your own)
│   └── icon.ico      ← Windows app icon (add your own)
└── package.json
```

## Invoice photos are stored at:
- **Mac**: `~/Library/Application Support/fox-flowers-invoices/uploads/`
- **Windows**: `%APPDATA%\fox-flowers-invoices\uploads\`
